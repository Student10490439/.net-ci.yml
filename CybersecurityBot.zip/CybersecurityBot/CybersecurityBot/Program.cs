﻿using System;
using System.IO;
using CybersecurityBot.Models;
using CybersecurityBot.Helpers;
using CybersecurityBot.Core;

namespace CybersecurityBot;

class Program
{
    static void Main()
    {
        Console.Clear();

        // Q2: ASCII Art Logo (Display once at start)
        DisplayLogo();

        // Q1: Voice Greeting - FIXED: Removed escaped quotes and double .wav extension
        string audioPath = @"C:\Users\Student\source\repos\CybersecurityBot\CybersecurityBot\greeting.wav";

        try
        {
            AudioHelper.PlayGreeting(audioPath);
        }
        catch (Exception ex)
        {
            // Silently fail or log if the audio file is missing so the bot still runs
            Console.WriteLine($"[System] Audio notification skipped: {ex.Message}");
        }

        ConsoleUI.PrintHeader("Cybersecurity Awareness Bot Initialized");

        // Q3: Text-based greeting & User Interaction
        ConsoleUI.TypeWriteLine("Welcome! To establish a secure session, please identify yourself.", ConsoleColor.Cyan);

        string name = GetValidName();
        var userSession = new UserProfile(name);

        ConsoleUI.TypeWriteLine($"\nHello, {userSession.Name}. Your secure session is active. Type 'exit' to quit.", ConsoleColor.Green);
        ConsoleUI.PrintDivider();

        // Pass control to the core engine
        var engine = new ChatbotEngine(userSession);
        engine.StartChatLoop();
    }

    private static void DisplayLogo()
    {
        Console.ForegroundColor = ConsoleColor.Blue;
        // Clean "Cyber Cop" block font for better console compatibility
        Console.WriteLine(@"
   ______      __              ______                
  / ____/_  __/ /_  ___  _____/ ____/___  ____      
 / /   / / / / __ \/ _ \/ ___/ /   / __ \/ __ \     
/ /___/ /_/ / /_/ /  __/ /  / /___/ /_/ / /_/ /     
\____/\__, /_.___/\___/_/   \____/\____/ .___/      
     /____/                           /_/           
        ");
        Console.ResetColor();
    }

    private static string GetValidName()
    {
        string? input;
        do
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write("Enter your name: ");
            Console.ResetColor();

            input = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(input))
            {
                // Assuming ConsoleUI is a static helper in your project
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Name cannot be blank.");
                Console.ResetColor();
            }
        } while (string.IsNullOrWhiteSpace(input));

        return input.Trim();
    }
}