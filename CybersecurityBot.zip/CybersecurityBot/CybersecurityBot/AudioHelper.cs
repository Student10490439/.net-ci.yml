﻿// File: Helpers/AudioHelper.cs
namespace CybersecurityBot.Helpers;

using System;
using System.IO;
using System.Media;
using System.Runtime.InteropServices;

public static class AudioHelper
{
    /// <summary>
    /// Plays a WAV file asynchronously. Only supported on Windows.
    /// </summary>
    /// <param name="filePath">The relative or absolute path to the .wav file.</param>
    
    public static void PlayGreeting(string filePath)
    {
        if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows) && File.Exists("C:\\Users\\Student\\Downloads\\CybersecurityBot\\CybersecurityBot\\CybersecurityBot\\WhatsApp Audio 2026-04-13 at 14.02.16 (online-audio-converter.com).wav"))
        {
            using SoundPlayer player = new SoundPlayer("C:\\Users\\Student\\Downloads\\CybersecurityBot\\CybersecurityBot\\CybersecurityBot\\WhatsApp Audio 2026-04-13 at 14.02.16 (online-audio-converter.com).wav");
            player.Play(); // Use .Play() for a smooth "Bot" feel
        }
    
        // System.Media.SoundPlayer is Windows-only. This prevents the app from crashing on Mac/Linux.
        if (!RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
        {
            ConsoleUI.WriteError("Audio playback is currently only supported on Windows environments.");
            return;
        }

        try
        {
            // Check if the file actually exists before trying to play it
            if (File.Exists(filePath))
            {
                using var player = new SoundPlayer("C:\\Users\\Student\\Downloads\\CybersecurityBot\\CybersecurityBot\\CybersecurityBot\\WhatsApp Audio 2026-04-13 at 14.02.16 (online-audio-converter.com).wav");

                // Using .Play() instead of .PlaySync() so the rest of the app 
                // continues to load while the audio plays in the background.
                player.Play();
            }
            else
            {
                
            }
        }
        catch (Exception ex)
        {
            ConsoleUI.WriteError($"An error occurred while trying to play the audio: {ex.Message}");
         
        }
    }
}